# OMFS Treatment Planner

Client-only React app to generate checklist-style treatment plans for common OMFS scenarios.

## Quick start (local)
```bash
npm install
npm run dev
```
Then open the shown localhost URL.

## Deploy to Vercel
1. Push this folder to a GitHub repository.
2. In Vercel: **New Project** → import the repo → Deploy.
3. Done. Open the provided URL.

> Styling uses Tailwind via CDN in `index.html` for simplicity (no build config required).
> Clinical decision-support only. Follow local protocols and senior/MDT guidance.
